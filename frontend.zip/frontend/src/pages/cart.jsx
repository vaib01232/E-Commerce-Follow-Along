import NavBar from '../components/auth/nav';
const Cart = () => {
    return (
        <>
            <NavBar />
            <div>
                <h1>Your Cart</h1>
            </div>
        </>
    );
}
export default Cart;